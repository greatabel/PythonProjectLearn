---
name: 新需求或建议
about: 建议开发新功能，或虽然没有新需求但对本项目有其它建议
title: ''
labels: 'feature'
assignees: ''

---

- 问：请说明需要什么新功能。<br>
答：

- 问：请说明添加该功能的意义。（非必填）<br>
答：

