class Parser:
    def __init__(self, cookie):
        self.cookie = cookie
        self.url = ''
        self.selector = None
