from django.shortcuts import render
from django.db import connection
from django.http import JsonResponse

# Create your views here.


def index(request):
	return render(request, 'AppTPCC/index.html')
	
	
def result(request):
	search_string = request.GET.get('search', '')
	
	query = f"SELECT * FROM item WHERE i_name ~ '{search_string}'"
	
	c = connection.cursor()
	
	c.execute(query)
	
	results = c.fetchall()
	
	result_dict = {'records': results}
	return render(request, 'AppTPCC/result.html', result_dict)

def report(request):
	return render(request, 'AppTPCC/report.html')


def query1(request):
	query = """
		SELECT s.w_id, SUM(s.s_qty) AS sum
		FROM item i, stock s
		WHERE i.i_id = s.i_id
		AND i.i_name = 'Aspirin'
		GROUP BY s.w_id
		UNION
		SELECT w.w_id, 0 AS sum
		FROM warehouse w
		WHERE w.w_id NOT IN (
			SELECT s.w_id
			FROM item i, stock s
			WHERE i.i_id = s.i_id
			AND i.i_name = 'Aspirin')
			ORDER BY sum DESC;
	"""
	c = connection.cursor()
	
	c.execute(query)
	
	results = c.fetchall()
	return JsonResponse(results, safe=False)
	