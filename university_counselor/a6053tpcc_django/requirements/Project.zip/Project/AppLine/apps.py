from django.apps import AppConfig


class ApplineConfig(AppConfig):
    name = 'AppLine'
