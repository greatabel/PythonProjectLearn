from django.apps import AppConfig


class AppdateConfig(AppConfig):
    name = 'AppDate'
