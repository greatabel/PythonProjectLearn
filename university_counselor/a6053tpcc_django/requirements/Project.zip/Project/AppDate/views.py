from django.shortcuts import render
from datetime import datetime

# Create your views here.

def my_custom_index(request):
	return render(request, 'AppDate/index.html')
	
	
	
def result(request):
    # Parse time from string into date time object
    date_string = request.GET.get('date', '')
    
    date = datetime.strptime(date_string, '%Y-%m-%d')
    year = date.strftime("%Y")
    iso_year = date.strftime("%G")
    month = date.strftime("%B")
    weekday = date.strftime("%A")
    iso_weekday = date.strftime("%u")
    iso_week = date.strftime("%V")

    result_dict = {
        'year': year,
        'iso_year': iso_year,
        'month': month,
        'weekday': weekday,
        'iso_weekday': iso_weekday,
        'iso_week': iso_week
    }

    return render(request,'AppDate/result.html', result_dict)